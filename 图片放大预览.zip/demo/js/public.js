/*提示框*/
function alertInfo(hd){
	if($('.am-Prompt').html()){
		$(".am-Prompt").remove();
		popup(hd)
	}else{
		popup(hd)
	}	
}
function popup(hd){
	var temStr = '<div class="am-Prompt "><div class="Prompt">'+hd+'</div></div>';
	$("body").append(temStr);
	$(".am-Prompt").show();
	$(".am-Prompt").addClass("animation")
	setTimeout(function(){
		$(".am-Prompt").removeClass("animation")
		$(".am-Prompt").hide();
	},2000)
}
function nav0(){
	$(".nav-box").eq(0).find("i").addClass("ones")
	$(".nav-box").eq(0).find("span").addClass("other")
}
function nav1(){
	$(".nav-box").eq(1).find("i").addClass("twos")
	$(".nav-box").eq(1).find("span").addClass("other")
}
function nav2(){
	$(".nav-box").eq(2).find("i").addClass("threes")
	$(".nav-box").eq(2).find("span").addClass("other")
}
function nav3(){
	$(".nav-box").eq(3).find("i").addClass("fours")
	$(".nav-box").eq(3).find("span").addClass("other")
}
function nav4(){
	$(".nav-box").eq(4).find("i").addClass("fives")
	$(".nav-box").eq(4).find("span").addClass("other")
}

//提交认证信息
function submitInfo(submit_url, callback_url){
	var form = document.getElementById("submit_form");
	var formData = new FormData(form);
	$.ajax({
		url  : submit_url,
		type : 'post',
		data : formData,
		dataType : 'json',
		contentType: false,  
        processData: false, 
		success  : function (data){
			if (data.code == 200){
				$("#load-modal").hide();
				alertInfo('提交成功');
				setTimeout(function(){
					window.location.href = callback_url;
				},500);
			}else{
				$("#load-modal").hide();
				alertInfo(data.info);
			}
		}
	});
}

//个人中心我的钱包绑定账号
function addBind(url, data, callback_url){
    $("#load-modal").show();
    $.ajax({
        url  : url,
        type : 'post',
        data : data,
        dataType : 'json',
        success  : function (data){
            $("#load-modal").hide();
            if (data.code == 200){
                alertInfo('绑定成功');
                setTimeout(function(){
                    window.location.href = callback_url;
                }, 800);
            }else{
                alertInfo(data.info);
            }
        }
    });
}

//密码框自动跳格
$('.prpmpt1').bind('input propertychange', function() { 
    $(this).next("input").focus();
})
$('.prpmpt2').bind('input propertychange', function() { 
    $(this).next("input").focus();
})
$('.prpmpt3').bind('input propertychange', function() { 
    $(this).next("input").focus();
})  
$('.prpmpt4').bind('input propertychange', function() { 
    $(this).next("input").focus();
})  
$('.prpmpt5').bind('input propertychange', function() { 
    $(this).next("input").focus();
}) 